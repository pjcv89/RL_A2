
function weights = cw2_solution2(option)

if option==0
    % Using Original features
    [weights,~,~] = sarsa(500);
elseif option==1
    % Using Custom features
    [weights, ~, ~] = sarsa_custom(500);
end