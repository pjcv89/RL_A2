function [params, amh, ars] = sarsa_custom(n_episodes)
%% Control algorithm: one-step SARSA with linear function approximation.
% Input: n_episodes - Number of episodes to run.
% Output: params - parameter tensor of dimension (4,5,number_of_actions)=(4,5,3)
%          amh - history of agentMovementHistory per each episode
%          ars - history of rewards per each episode
%% Hyperparameters
% Step size (i.e. learning rate)
step_size = .001;
% Discount factor
gamma=1;
%% Problem specification
blockSize = 5 ;
n_MiniMapBlocksPerMap = 5 ;
episodeLength = blockSize*n_MiniMapBlocksPerMap - 1;
rewards = [ 1, -1, -20 ] ;
probabilityOfUniformlyRandomDirectionTaken = 0.15; 
roadBasisGridMaps = generateMiniMaps; 
noCarOnRowProbability = 0.8;

%% Initialising the state-action function randomly
rng(123)
Q_test1 = rand(4, 5, 3);

%% Initialising the parameters with zeros
params = zeros(4, 5, 3);

%% To keep track of information about each episode
%agentMovementHistory
amh = zeros(episodeLength+1, 2, n_episodes);
%Rewards
ars = zeros(episodeLength+1, n_episodes);

%% Auxiliary functions
% Similar to NumPy's random choice function
function F = randomchoice(P,X)
% Choose seudorandomly an element from X with respective probabilities in P
x = cumsum([0 P(:).'/sum(P(:))]);
x(end) = 1e3*eps + x(end);
[a, a] = histc(rand,x);
F = X(a);
end

% Choose action in a epsilon greedy fashion.
function actionTaken = eps_greedy(stateFeatures,Q_test,eps)
        
        % CUSTOM STATE FEATURES
        y = [4 3 2 1];
        y = y.^2;
        y = 1 ./ y;
        % IDEA: GIVE PRIORITY TO NEAREST ROWS
       for j=1:4
       stateFeatures(j,:)=y(j)*stateFeatures(j,:);
       end
       
        probs = ones(3,1) * eps / 3;
        action_values = zeros(1, 3);
        
        for ac = 1:3
            action_values(ac) = ...
                sum ( sum( Q_test(:,:,ac) .* stateFeatures ));
        end % for each possible action
        [~, bestAction] = max(action_values);
     probs(bestAction) = probs(bestAction) + 1 - eps;
     actionTaken = randomchoice(probs,[1,2,3]);
end

%% Main loop: Episodic semi-gradient SARSA
for episode = 1:n_episodes
    
    currentTimeStep = 0 ;
    rng(episode);
    MDP = generateMap( roadBasisGridMaps, n_MiniMapBlocksPerMap, ...
        blockSize, noCarOnRowProbability, ...
        probabilityOfUniformlyRandomDirectionTaken, rewards );
    
    agentLocation = MDP.Start;

    agentMovementHistory = zeros(episodeLength+1, 2) ;
    agentMovementHistory(currentTimeStep + 1, :) = agentLocation ;
        
    realAgentLocation = agentLocation ; 
    % Initial state and action of episode
    stateFeatures = MDP.getStateFeatures(realAgentLocation);
    actionTaken = eps_greedy(stateFeatures,Q_test1,.10);  
    
    for i = 1:episodeLength            
        % Take action A, observe reward R and new state S'
        [ reward, realAgentLocation, currentTimeStep, ...
            agentMovementHistory ] = ...
            actionMoveAgent( actionTaken, realAgentLocation, MDP, ...
            currentTimeStep, agentMovementHistory, ...
            probabilityOfUniformlyRandomDirectionTaken);
        
        amh(:,:,episode) = agentMovementHistory;
        ars(i,episode) = reward;
        
        %If new state is not terminal, do:
        if i~= episodeLength
            next_stateFeatures = MDP.getStateFeatures(realAgentLocation);
        
        %Choose A' as function of q(S',.,params)
            %Q = params .* next_stateFeatures;
            new_actionTaken = eps_greedy(next_stateFeatures,params,.10);
    
            %Update rule step
            tmp = params(:,:,actionTaken);
            tmp = tmp(:);
        
            n_tmp = params(:,:,new_actionTaken);
            n_tmp = n_tmp(:);
        
            target = reward + gamma*dot(n_tmp,transpose(next_stateFeatures(:)));
            params(:,:,actionTaken) = params(:,:,actionTaken) + ...
                           step_size*(target - dot(tmp,transpose(stateFeatures(:)))).* stateFeatures;
            % Update state S and action A   
            stateFeatures = next_stateFeatures;
            actionTaken = new_actionTaken;
        %Otherwise, if new state is terminal, do:
        else 
            target = reward;
            params(:,:,actionTaken) = params(:,:,actionTaken) + ...
                           step_size*(target - dot(tmp,transpose(stateFeatures(:)))).* stateFeatures;
        end
    end %for each step in episode
%Decrease the learning rate after each episode
step_size = step_size*.99; 
end % for each episode

end
