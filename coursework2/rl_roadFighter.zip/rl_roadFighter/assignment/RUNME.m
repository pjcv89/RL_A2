
%% SCRIPT FOR RUNNING SOLUTIONS TO BOTH EXERCISE 1 AND 2

%% EXERCISE 1
% Monte Carlo
weights_mc = cw2_solution1(0);
% TD Learning
weights_td = cw2_solution1(1);

%% EXERCISE 2
% Original features
wstar_original = cw2_solution2(0);
% Custom features
wstar_custom = cw2_solution2(1);

%% Test solution
Q_test1 = wstar_original;
% Visualize 5 realisations using optimal Q function found via SARSA control
cw2_exercise1_mod