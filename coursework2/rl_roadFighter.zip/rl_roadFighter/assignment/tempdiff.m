function [params, amh, ars] = tempdiff(n_episodes)

%% Policy evaluation: TD(0) with linear function approximation.
% Input: n_episodes - Number of episodes to run.
% Output: params - parameter tensor of dimension (4,5,number_of_actions)=(4,5,3)
%          amh - history of agentMovementHistory per each episode
%          ars - history of rewards per each episode
%% Hyperparameters
% Step size (i.e. learning rate)
step_size = .001;
% Discount factor
gamma=1;
%% Problem specification
blockSize = 5 ;
n_MiniMapBlocksPerMap = 5 ;
episodeLength = blockSize*n_MiniMapBlocksPerMap - 1;
rewards = [ 1, -1, -20 ] ;
probabilityOfUniformlyRandomDirectionTaken = 0.15; 
roadBasisGridMaps = generateMiniMaps; 
noCarOnRowProbability = 0.8;
%% Initialising  the exercise approximate Q-function:
Q_test1 = ones(4, 5, 3);
Q_test1(:,:,1) = 100;
Q_test1(:,:,3) = 100;
%% Initialising the parameters with zeros
params = zeros(4, 5, 3);
%% To keep track of information about each episode
%agentMovementHistory
amh = zeros(episodeLength+1, 2, n_episodes);
%Rewards
ars = zeros(episodeLength+1, n_episodes);
%% Auxiliary functions
% Similar to NumPy's random choice function
function F = randomchoice(P,X)
% Choose seudorandomly an element from X with respective probabilities in P
x = cumsum([0 P(:).'/sum(P(:))]);
x(end) = 1e3*eps + x(end);
[a, a] = histc(rand,x);
F = X(a);
end

% Choose action in a greedy fashion, breaking ties seudorandomly.
function actionTaken = greedy(stateFeatures,Q_test)
    action_values = zeros(1, 3);
        for ac = 1:3
            action_values(ac) = ...
                sum ( sum( Q_test(:,:,ac) .* stateFeatures ) );
        end % for each possible action
        [value, bestAction] = max(action_values);
        finder = find(action_values == value);
        nf = length(finder);
        if nf > 1 
            probs = ones(nf,1)/ nf;
            actionTaken = randomchoice(probs,finder);
        else
            actionTaken = bestAction;
        end
end

%% Main loop: Semigradient TD(0)
for episode = 1:n_episodes
    
    currentTimeStep = 0 ;
    rng(episode);
    MDP = generateMap( roadBasisGridMaps, n_MiniMapBlocksPerMap, ...
        blockSize, noCarOnRowProbability, ...
        probabilityOfUniformlyRandomDirectionTaken, rewards );
    
    agentLocation = MDP.Start;

    agentMovementHistory = zeros(episodeLength+1, 2) ;
    agentMovementHistory(currentTimeStep + 1, :) = agentLocation ;
        
    realAgentLocation = agentLocation ; 
    
    for i = 1:episodeLength
        % Choose action following the given policy
        stateFeatures = MDP.getStateFeatures(realAgentLocation); 
        actionTaken = greedy(stateFeatures,Q_test1);                
         % Take action A, observe reward R and new state S'
        [ reward, next_AgentLocation, currentTimeStep, ...
            agentMovementHistory ] = ...
            actionMoveAgent( actionTaken, realAgentLocation, MDP, ...
            currentTimeStep, agentMovementHistory, ...
            probabilityOfUniformlyRandomDirectionTaken);
            
        next_stateFeatures = MDP.getStateFeatures(next_AgentLocation);
        actionTaken = greedy(next_stateFeatures,Q_test1);
        
        %Update rule step
        tmp = params(:,:,actionTaken);
        tmp = tmp(:);
        
        target = reward + gamma*dot(tmp,transpose(next_stateFeatures(:)));

        params(:,:,actionTaken) = params(:,:,actionTaken) + ...
                           step_size*(target - dot(tmp,transpose(stateFeatures(:)))).* stateFeatures;
        realAgentLocation=next_AgentLocation;
    end %for each step in episode
%Decrease the learning rate after each episode
step_size = step_size*.9;           
end % for each episode

end
