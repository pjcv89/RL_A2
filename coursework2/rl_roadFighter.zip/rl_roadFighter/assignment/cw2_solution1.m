
function weights = cw2_solution1(option)

if option==0
    % Using Monte Carlo
    [weights,~,~] = montecarlo(200);
elseif option==1
    % Using TD(0)
    [weights, ~, ~] = tempdiff(200);
end